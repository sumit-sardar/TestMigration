#!/bin/sh
java -cp fitnesse.jar fitnesse.Fitnesse $1 $2 $3 $4 $5
